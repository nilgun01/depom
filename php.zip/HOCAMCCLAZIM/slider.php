﻿<?php include 'header.php';
 include'sidebar.php';

if(!isset($_SESSION['admin_kadi'])){
	
	header('Location:login.php');
		
}


 ?>
<!-- ara kodlar -->

          <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">SİLİDER</h1>
                        <h1 class="page-subhead-line">Sitenizdeki Siliderları Bu Sayfadan Yönetebilirsiniz. </h1>

                    </div>
                </div>
                
				<div class="col-md-12">
					
					<a href="sliderekle.php"><button class="btn btn-success">Slider  Ekle</button> </a>
					<hr>
					
				</div>
                
                <div class="col-md-12">
                     <!--    Hover Rows  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Ekli Olan Sliderlar
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th >Slider Adı</th>
                                            <th >Slider Resim</th>
                                            <th >Slider Link</th>
                                            <th >Slider Sıra</th>
                                            
                                            <th></th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
			    
			  $slidersor=mysql_query(" select * from  slider ");
				  
		      while ($slidercek=mysql_fetch_assoc($slidersor)) {?>
                                       
                                       
                                       
                                        <tr>
                                            <td><?php echo $slidercek['slider_id'];?></td>
                                            <td><?php echo $slidercek['slider_ad'];?> </td>
                                             <td>
                                             
                                              <img width="200" src="<?php echo $slidercek['slider_resim'];?>">
                                                </td>
                                            <td><?php echo $slidercek['slider_url'];?> </td>
                                            <td><?php echo $slidercek['slider_sira'];?> </td>
                                           
                                            
                                            <td><a href="islem.php?slider_id=<?php echo $slidercek['slider_id'];?>&slidersil=ok"><button class="btn btn-danger">Sil</button></a></td>
                                        </tr>
                                        
                                        
                                        
                                        
                                        <?php }?>
                                        
                                        
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- End  Hover Rows  -->
                </div>
                

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
        
    
    <!-- ara kodlar -->

    


<?php include('footer.php');?>