﻿<?php 
include 'baglanti/baglanti.php';


//burada ayarlar tablosunun güncellerme işlemi yapılmıştır

   if (isset($_POST['ayarkaydet'])){
	   
	  $id=0;
	   
	   $ayar_kaydet=mysql_query("update ayarlar set ayar_title='".$_POST['ayar_title']."',ayar_desc='".$_POST['ayar_desc']."',ayar_keywords='".$_POST['ayar_keywords']."',ayar_telefon='".$_POST['ayar_telefon']."',ayar_facebook='".$_POST['ayar_facebook']."',ayar_twitter='".$_POST['ayar_twitter']."',ayar_footer='".$_POST['ayar_footer']."',ayar_adres='".$_POST['ayar_adres']."',ayar_mail='".$_POST['ayar_mail']."',ayar_fax='".$_POST['ayar_fax']."'where ayar_id='$id'");
	  
	   
	   
	   if(mysql_affected_rows())
		   
		   
	   {
		   
		   header("Location:ayarlar.php?durum=ok");
		   
		   
	   }
	   else{
		   header("Location:ayarlar.php?durum=hayir");
		   
	   }
   }


// ayarlar işleminin sonu...

// Admin Giriş Yeti alanı

if(isset($_POST['loggin']))
{
	
	$admin_kadi = $_POST['admin_kadi'];
	$admin_sifre =md5($_POST['admin_sifre']);
	
	if($admin_kadi && $admin_sifre){
		
		
		$sorgu = mysql_query("select * from kullanici where admin_kadi='$admin_kadi' and admin_sifre='$admin_sifre'");
		
		$verisay = mysql_num_rows($sorgu);
		
		if($verisay>0){
			
			
			$_SESSION['admin_kadi']= $admin_kadi;
			header('Location:index.php');
			
		}
		else{
			
			
			header('Location:login.php?login=no');
		}
		
	}
	
	
	// Admin Giriş Yeti alanı SON .
	
	
	
}

/// MENU EKLEME ALANI.

	if(isset($_POST['menukaydet'])){
		
		
		$menuekle=mysql_query("insert into menu (menu_adi,menu_link)VALUES ('".$_POST['menu_adi']."','".$_POST['menu_link']."')");
		
		if(mysql_affected_rows())
		{
			
			header("Location:menuekle.php?durum=ok");
			
		}
		else{
		
			
			header("Location:menuekle.php?durum=no");
			
			
		}
		
	}


/// MENU EKLEME ALANI SON.

/// MENU DUZENLEME ALANI.


if (isset($_POST['menuduzenle'])){
	   
	$menu_id=$_POST['menu_id'];
	  
	   
	   $menu_duzenle=mysql_query("update menu set menu_adi='".$_POST['menu_adi']."', menu_link='".$_POST['menu_link']."' where menu_id='$menu_id'");
	  
	   
	   
	   if(mysql_affected_rows())
		   
		   
	   {
		   
		   header("Location:menuduzenle.php?durum=ok&menu_id=$menu_id");
		   
		   
	   }
	   else{
		   header("Location:menuduzenle.php?durum=hayir&menu_id=$menu_id");
		   
	   }
   }


/// MENU DUZENLEME ALANI SON. 


if($_GET['menusil']=="ok"){
	
	$menusil=mysql_query("delete from menu where menu_id = '".$_GET['menu_id']."'");
	
	if(mysql_affected_rows())
	{
		
		header('Location:menuler.php?durum=ok');
		
	}
	else{
		
			header('Location:menuler.php?durum=no');
		
	}
	
}

/// SİLİDER EKLEME ALANI 

if(isset($_POST['sliderekle'])){
	
	$uploads_dir = 'uploads';
	
	$tmp_name = $_FILES['sliderres']["tmp_name"];
	
	$name = $_FILES['sliderres']["name"];
	
	$sayiat1 = rand(20000,32000);
	$sayiat2 = rand(20000,32000);
	$sayiat3 = rand(20000,32000);
	$sayiat4 = rand(20000,32000);
	
	$sayiadi=$sayiat1.$sayiat2.$sayiat3.$sayiat4;
	$resimyol = $uploads_dir."/".$sayiadi.$name;
	move_uploaded_file($tmp_name,$uploads_dir."/".$sayiadi.$name);
	
	$slider_ekle = mysql_query("insert into slider (slider_resim,slider_ad,slider_url,slider_sira)
	
	VALUES ('".$resimyol."','".$_POST['slider_ad']."','".$_POST['slider_url']."','".$_POST['slider_sira']."')");
	
	
	if(mysql_affected_rows())
	{
		
		header("Location:sliderekle.php?durum=ok");
	}
	 else
	 {
		 
		 header("Location:sliderekle.php?durum=no");
	 }

	
}

/// SİLİDER EKLEME ALANI SON 

/// SİLİDER SİLME

if($_GET['slidersil']=="ok"){
	
	$slidersil=mysql_query("delete from slider where slider_id = '".$_GET['slider_id']."'");
	
	if(mysql_affected_rows())
	{
		
		header('Location:slider.php?durum=ok');
		
	}
	else{
		
			header('Location:slider.php?durum=no');
		
	}
	
}
/// SİLİDER SİLME SON

//// SAYFA EKLEME  ALANI 


if(isset($_POST['sayfakaydet'])){
	
	
	$zaman =date('Y-m-d H:i');
		
		
		$sayfaekle=mysql_query("insert into sayfalar (sayfa_ad,sayfa_icerik,sayfa_sira,sayfa_anasayfa,sayfa_tarih)VALUES ('".$_POST['sayfa_ad']."','".$_POST['sayfa_icerik']."','".$_POST['sayfa_sira']."','".$_POST['sayfa_anasayfa']."','".$zaman."')");
		
		if(mysql_affected_rows())
		{
			
			header("Location:sayfalar.php?durum=ok");
			
		}
		else{
		
			
			header("Location:sayfalar.php?durum=no");
			
			
		}
		
	}





?>