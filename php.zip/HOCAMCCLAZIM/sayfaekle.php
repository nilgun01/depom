﻿<?php include 'header.php'; ?>
<?php include'sidebar.php';?>
<!-- ara kodlar -->

          <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Sayfa Ekleme Alanı</h1>
                        
                        <?php
						
					if ($_GET['durum']=="ok"){?>
						
						
						<h1 style="color: green"class="page-subhead-line">Sayfa Ekleme Başarılı  </h1>
						
					<?php } elseif ($_GET['durum']=="hayir"){?>
						
						
						
						
						<h1 style="color: darkred" class="page-subhead-line">Sayfa Ekleme Başarısız HATA... </h1>
						
					<?php } else {?>
					
						<h1 class="page-subhead-line">Sitenize Sayfa  Ekliyorsunuz. </h1>
						
						
				<?php	}	?>
						
						
                        

                    </div>
                </div>
                <!-- /. ROW  -->
                <form action="islem.php" method="POST">
                	
                	                	     <div class="form-group col-lg-6">
                                            <label>Sayfa Adı</label>
                                            <input class="form-control" type="text" name="sayfa_ad" placeholder="Sayfa Adı Giriniz">
                                          
                                            </div>
                                            
                                            <div class="form-group col-lg-12">
                                            <label>Sayfa İçerik</label>
                                            <textarea name="sayfa_icerik" class="ckeditor"></textarea>
                                          
                                            </div>
                                              
                                               <div class="form-group col-lg-6">
                                            <label>Sayfa Sıra</label>
                                            <input class="form-control" type="text" name="sayfa_sira" placeholder="Sayfa Sıra">
                                          
                                            </div>
                                              
                                              <div class="form-group col-lg-6">
                                            <label>Anasayfa Göster</label>
                                            <select  name="sayfa_anasayfa" class="form-control">
                                                <option value="0">HAYIR</option>
                                                <option value="1">EVET</option>
                                               
                                            </select>
                                        </div>
                                               <div class="form-group col-lg-6">
                                          
                                            <input  style="width:100% "class="btn btn-success" type="submit"name="sayfakaydet" value="SAYFA EKLE"></div>
                                            
                                            </div>
                                            
                                  
                                          
                                          
                                            
                	
                	
                </form>
                

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
        
    
    <!-- ara kodlar -->

    


<?php include('footer.php');?>