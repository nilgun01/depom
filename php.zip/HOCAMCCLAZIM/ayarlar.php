﻿<?php include 'header.php'; ?>
<?php include'sidebar.php';?>
<!-- ara kodlar -->

          <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Site Genel Ayarları</h1>
                        
                        <?php
						
					if ($_GET['durum']=="ok"){?>
						
						
						<h1 style="color: green"class="page-subhead-line">Kayıt Güncelleme Başarılı... </h1>
						
					<?php } elseif ($_GET['durum']=="hayir"){?>
						
						
						
						
						<h1 style="color: darkred" class="page-subhead-line">Kayıt Güncelleme Başarısız HATA... </h1>
						
					<?php } else {?>
					
						<h1 class="page-subhead-line">Sitenizdeki Temel Ayarları Bu Bölümden Yapabilirsiniz. </h1>
						
						
				<?php	}	?>
						
						
                        

                    </div>
                </div>
                <!-- /. ROW  -->
                <form action="islem.php" method="post">
                	
                	                	     <div class="form-group col-lg-6">
                                            <label>Site Başlık</label>
                                            <input class="form-control" type="text" name="ayar_title" value="<?php echo $ayar_cek['ayar_title']; ?>">
                                          
                                            </div>
                                            
                                            <div class="form-group col-lg-6">
                                            <label>Site Açıklaması </label>
                                            <input class="form-control" type="text" name="ayar_desc" value="<?php echo $ayar_cek['ayar_desc']; ?>">
                                          
                                            </div>
                                             <div class="form-group col-lg-6">
                                            <label>Keyword</label>
                                            <input class="form-control" type="text" name="ayar_keywords" value="<?php echo $ayar_cek['ayar_keywords']; ?>">
                                          
                                            </div>
                	
                	
                	                        <div class="form-group col-lg-6">
                                            <label>Telefon</label>
                                            <input class="form-control" type="text" name="ayar_telefon" value="<?php echo $ayar_cek['ayar_telefon']; ?>">
                                          
                                            </div>
                                             <div class="form-group col-lg-6">
                                            <label>Facebook</label>
                                            <input class="form-control" type="text" name="ayar_facebook" value="<?php echo $ayar_cek['ayar_facebook']; ?>">
                                          
                                            </div>
                                             <div class="form-group col-lg-6">
                                            <label>Twitter</label>
                                            <input class="form-control" type="text" name="ayar_twitter" value="<?php echo $ayar_cek['ayar_twitter']; ?>">
                                          
                                            </div>
                                             <div class="form-group col-lg-12">
                                            <label>Footor ayar</label>
                                            <input class="form-control" type="text" name="ayar_footer" value="<?php echo $ayar_cek['ayar_footer']; ?>">
                                          
                                            </div>
                                            <div class="form-group col-lg-12">
                                            <label>Ayar Adres</label>
                                            <input class="form-control" type="text" name="ayar_adres" value="<?php echo $ayar_cek['ayar_adres']; ?>">
                                          
                                            </div>
                                             <div class="form-group col-lg-6">
                                            <label>Maile</label>
                                            <input class="form-control" type="text" name="ayar_mail" value="<?php echo $ayar_cek['ayar_mail']; ?>"></div>
                                            
                                             <div class="form-group col-lg-6">
                                            <label>fax</label>
                                            <input class="form-control" type="text" name="ayar_fax" value="<?php echo $ayar_cek['ayar_fax']; ?>"></div>
                                          
                                            <div class="form-group col-lg-6">
                                          
                                            <input  style="width:100% "class="btn btn-success" type="submit"name="ayarkaydet" value="AYARLARI KAYDET"></div>
                                            
                                            </div>
                                            
                	
                	
                </form>
                

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
        
    
    <!-- ara kodlar -->

    


<?php include('footer.php');?>