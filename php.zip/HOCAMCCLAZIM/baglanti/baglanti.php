﻿<?php 
ob_start();
session_start();
?>


<?php 

$kullanici="u755096945_nil";
$sifre="123456";
$sunucu="localhost";
$db="u755096945_nil";


$baglan=mysql_connect($sunucu,$kullanici,$sifre);
mysql_query("SET NAMES UTF8");
if(!$baglan)
{
	mysql_close($baglan);
	echo"veri tabanına baglantı yapılamadı";
	exit();
	
	
}

$db=mysql_select_db($db);

if(!$db){
	
	echo "Veritabanı hatası:". mysql_error(); echo "<br>";
		echo "veri tabanına baglantı yapılamadı";
	exit();
	
}