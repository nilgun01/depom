﻿<?php include 'header.php';
 include'sidebar.php';

if(!isset($_SESSION['admin_kadi'])){
	
	header('Location:login.php');
		
}


 ?>
<!-- ara kodlar -->

          <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">ADMİN PANEL </h1>
                        <h1 class="page-subhead-line">Site Yönetimi İçin Soltaraftaki Menüleri Kullanabilirsiniz. </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
        
    
    <!-- ara kodlar -->

    


<?php include('footer.php');?>